/*
var myFirebaseRef = new Firebase("https://bachelor-party-classic.firebaseio.com/");
$("document").ready(function(){
    console.log('aTest');
    $("#submit-button").click(function(){
        console.log('test1');
        var name = $('#name').val();
        var teamname = $('#teamname').val();
        alert(name +" is now on "+ teamname);
        $.cookie('username', name  );
        $.cookie('teamname', teamname);

        myFirebaseRef.push({
            Name: name,
            TeamName: teamname
        });
    });
});
$("document").ready(function(){
    console.log('aTest');
    $("#cookie-btn").click(function(){
        console.log('test1');
        var myCookies = $.cookie();
        alert('cookies='+JSON.stringify(myCookies));
        //alert("Here are the cookies" + " " +$.cookie("username")+" "+$.cookie("teamname"));

    });

    // myFirebaseRef.on('change','scoreTable'){
    //     calculatedScore = <some value>
    //     $('#myScore').value = calculatedScore
    // }
});
*/

